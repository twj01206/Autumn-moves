delete from T_USERINFO;

insert into T_USERINFO(username,passwd,appname) values('ty','typwd','台风网');
insert into T_USERINFO(username,passwd,appname) values('sms','smspwd','短信平台');

