sh tmp1.sh&
sh tmp2.sh&
sh tmp3.sh&
